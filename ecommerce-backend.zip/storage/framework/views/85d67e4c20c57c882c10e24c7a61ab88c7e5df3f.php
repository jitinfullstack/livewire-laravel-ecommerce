<?php echo e($slot); ?>

<?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel - Angular eCommerce\ecommerce-backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>