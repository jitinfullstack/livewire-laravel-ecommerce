<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH E:\Laravel Developement\Laravel - Angular Portfolio\Laravel - Angular eCommerce\ecommerce-backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>